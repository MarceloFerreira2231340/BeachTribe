<?php $__env->startSection('title','Contactos'); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/normalize.')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/Samuel/style.css?v=1.0')); ?>">
<link rel="website icon" type="image/apng" href="img/DarkSolo.png">
<link rel="stylesheet" href="https://use.typekit.net/oov2wcw.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<body>
    <div id="nav_spacer"></div>

    <div class="contact-container">
        <h1>Contacte-nos</h1>
        <p>Bem vindo à nossa página de contactos, se tiver alguma dúvida preencha os campos a baixo.</p>
      
        <form>
          <label for="name">Nome:</label>
          <input type="text" id="name" name="name" required>
      
          <label for="email">Email:</label>
          <input type="email" id="email" name="email" required>
      
          <label for="message">Mensagem:</label>
          <textarea id="message" name="message" required></textarea>
      
          <button type="submit">Submeter</button>
        </form>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\BeachTribe\BeachTribe\BeachTribe\resources\views/contactos.blade.php ENDPATH**/ ?>