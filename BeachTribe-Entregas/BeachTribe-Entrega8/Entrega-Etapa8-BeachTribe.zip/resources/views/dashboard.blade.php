@extends('layout.admin')
	@section('content')
		<h2>Dashboard</h2>
		<p>Bem Vindo!</p>
	@endsection
